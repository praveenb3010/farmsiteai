# URI

```{eval-rst}
.. automodule:: vibe_core.uri
   :members:
   :show-inheritance:
```

```{eval-rst}
.. autosummary::
   :toctree: _autosummary
```
