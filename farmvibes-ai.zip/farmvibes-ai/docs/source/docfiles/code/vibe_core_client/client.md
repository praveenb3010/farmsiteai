# FarmVibes.AI Client

```{eval-rst}
.. automodule:: vibe_core.client
   :members:
   :show-inheritance:
   :private-members: _form_payload

.. autosummary::
   :toctree: _autosummary
```
